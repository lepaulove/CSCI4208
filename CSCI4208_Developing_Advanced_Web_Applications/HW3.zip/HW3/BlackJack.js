let bet = 0;
