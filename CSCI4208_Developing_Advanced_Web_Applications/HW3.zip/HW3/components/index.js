ReactDOM.render(
    <App />,
    document.getElementById('root')
);