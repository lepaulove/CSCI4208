//Mounts App's view to the target HTML element & render to Browswer from ReactDOM
ReactDOM.render(<App /> , document.getElementById ('root')); 