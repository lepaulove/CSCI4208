class Welcome extends React.Component{
    render(){
        return(
            <div className="jumbotron">
                <div className="container" id="home">
                    <h1> My Title Here. </h1>
                    <p>Description goes here</p>
                </div>
            </div>
        );
    }
}